// Nonnon Spider
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#include "../nonnon/game/hmidiout.c"




#define N_SPIDER_MIDI_CHANNEL_MAX (  4 )


#define N_SPIDER_MIDI_SOUND       ( 10 )// "Music Box"
#define N_SPIDER_MIDI_NOTE_BASE   ( 48 )




const int n_spider_midi_c_major[ N_SPIDER_CARD_UNIT ] = {

	N_SPIDER_MIDI_NOTE_BASE,
	N_SPIDER_MIDI_NOTE_BASE + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2 + 1,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2 + 1 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2 + 1 + 2 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2 + 1 + 2 + 2 + 1,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2 + 1 + 2 + 2 + 1 + 2,
	N_SPIDER_MIDI_NOTE_BASE + 2 + 2 + 1 + 2 + 2 + 2 + 1 + 2 + 2 + 1 + 2 + 2,

};




#define n_spider_midi_note_on(  p ) n_spider_midi_note( p, n_true  )
#define n_spider_midi_note_off( p ) n_spider_midi_note( p, n_false )

void
n_spider_midi_note( n_spider *p, n_bool is_on )
{

	int note = n_spider_midi_c_major[ p->sequence_c ];

	int ch = 0;
	n_posix_loop
	{

		int vol = 0;
		if ( is_on ) { vol = N_HMIDIOUT_VOLUME_MAX; }

		n_hmidiout_all( 0, N_SPIDER_MIDI_SOUND, N_HMIDIOUT_PANPOT_CENTER, note, vol );

		ch++;
		if ( ch >= N_SPIDER_MIDI_CHANNEL_MAX ) { break; }
	}


	return;
}


