// Nonnon Paint
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




// internal
double
n_paint_pen_edge( n_type_gfx x, n_type_gfx y, s32 r, double coeff, double blend )
{
	return coeff * blend;
}

double
n_paint_pen_air( n_type_gfx x, n_type_gfx y, n_type_gfx radius, double coeff, double blend )
{

	if ( 0 == n_random_range( air ) )
	{
		coeff = n_paint_pen_edge( x,y, radius, coeff, blend );
		coeff = coeff * ( 1.0 / 7.5 );
	} else {
		coeff = 0;
	}


	return coeff;
}

// internal
int
n_paint_average( u32 color )
{

	int a = n_bmp_a( color );
	int r = n_bmp_r( color );
	int g = n_bmp_g( color );
	int b = n_bmp_b( color );


	return ( a + r + g + b ) / 4;
}

// internal
void
n_paint_pen_engine( n_type_gfx fx, n_type_gfx fy, double blend )
{

	if ( blend == 0.0 ) { return; }


	n_type_gfx radius = n_paint_pen_radius;
	u32        color  = n_paint_pen_color;

	if ( n_paint_quick_eraser ) { color = n_paint_tool_color_transparent_get(); }


	// [Patch] : size will be smaller when smooth is ON

	if ( blend < 1.0 ) { radius++; }

//n_win_hwndprintf_literal( hwnd_main, "%d %x %f", radius, color, blend );
//n_win_hwndprintf_literal( hwnd_main, "%d", pensize );


	n_posix_bool multi_layer_eraser = n_posix_false;

	if (
		( n_paint_grabber_wholegrb_onoff )
		&&
		( n_paint_layer_multiselect )
		&&
		( color == n_bmp_white_invisible )
	)
	{
		multi_layer_eraser = n_posix_true;
	}


	n_type_gfx x = -radius;
	n_type_gfx y = -radius;
	n_posix_loop
	{

		double coeff;
		if (
			( radius == 0 )
			||
			( n_bmp_ellipse_detect_coeff( x,y, radius,radius, &coeff ) )
		)
		{

			n_type_gfx tx = fx + x;
			n_type_gfx ty = fy + y;


			// [!] : don't use -1 == 0xffffffff == n_bmp_argb( 255,255,255,255 )

			u32 color_f = color + 1;
			u32 color_t = color;

			if ( n_paint_pen_whole_eraser_onoff )
			{

				n_type_int i = 0;
				n_posix_loop
				{

					if ( n_paint_layer_is_locked( i ) )
					{
						//
					} else
					if ( n_paint_layer_data[ i ].visible )
					{
						n_bmp *bmp = &n_paint_layer_data[ i ].bmp_data;


						double d;
						if ( air )
						{
							d = n_paint_pen_air ( x,y, radius, coeff, blend );
						} else {
							d = n_paint_pen_edge( x,y, radius, coeff, blend );
						}


						n_bmp_ptr_get( bmp, tx,ty, &color_f );

						color_t = color;//n_bmp_white_invisible;
						color_t = n_bmp_blend_pixel( color_f, color_t, d );

						n_bmp_ptr_set( bmp, tx,ty,  color_t );
					}


					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}

				n_bmp_ptr_set( &n_paint_bmp_wgrb, tx,ty, 0 );

			} else
			if ( multi_layer_eraser )
			{
//color_t = n_bmp_rgb( 0,200,255 );

				n_type_gfx gx,gy; n_paint_grabber_system_get( &gx,&gy, NULL,NULL, NULL,NULL );

				n_type_gfx orig_x = tx;
				n_type_gfx orig_y = ty;
				n_type_gfx grab_x = tx - gx;
				n_type_gfx grab_y = ty - gy;

				n_type_int i = 0;
				n_posix_loop
				{

					n_bmp *bmp_data = &n_paint_layer_data[ i ].bmp_data;
					n_bmp *bmp_grab = &n_paint_layer_data[ i ].bmp_grab;

					u32 c1;
					n_bmp_ptr_get( bmp_data, orig_x,orig_y, &c1 );

					u32 c2;
					n_bmp_ptr_get( bmp_grab, grab_x,grab_y, &c2 );

					double d;
					if ( air )
					{
						d = n_paint_pen_air ( x,y, radius, coeff, blend );
					} else {
						d = n_paint_pen_edge( x,y, radius, coeff, blend );
					}

					c1 = n_bmp_blend_pixel( c2, c1, d );
					n_bmp_ptr_set( bmp_grab, grab_x,grab_y,  c1 );

					n_bmp_ptr_set( &n_paint_bmp_wgrb, grab_x,grab_y, 0 );

					i++;
					if ( i >= n_paint_layer_count ) { break; }
				}

			} else
			if ( mix == 100 )
			{

				n_paint_grabber_pixel_get( n_paint_bmp_grab, tx,ty, color  , &color_f, &color_t, 0.0 );
				n_paint_grabber_pixel_set(                   tx,ty, color_f,  color_t                );

			} else {

				if ( n_paint_pen_boost != 0 )
				{
					if ( pensize == 0 )
					{
						if ( ( x == 0 )&&( y == 0 ) )
						{
							coeff /= radius;
						} else {
							coeff = 0.0;
						}
					} else
					if ( pensize == 1 )
					{
						if ( ( x ==  0 )&&( y ==  0 ) )
						{
							coeff /= radius * 0.5;
						} else
						if ( ( x == -1 )&&( y ==  0 ) )
						{
							coeff /= radius;
						} else
						if ( ( x ==  1 )&&( y ==  0 ) )
						{
							coeff /= radius ;
						} else
						if ( ( x ==  0 )&&( y == -1 ) )
						{
							coeff /= radius;
						} else
						if ( ( x ==  0 )&&( y ==  1 ) )
						{
							coeff /= radius;
						} else {
							coeff = 0.0;
						}
					} else {
						if ( n_bmp_ellipse_detect_coeff( x,y, pensize,pensize, NULL ) )
						{
							coeff /= radius;
						} else {
							coeff = 0.0;
						}
					}
				}

				if ( coeff != 0.0 )
				{
					if ( air )
					{
						n_paint_grabber_pixel_get( n_paint_bmp_grab, tx,ty, color, &color_f, &color_t, 0.25 );
						coeff = n_paint_pen_air ( x,y, radius, coeff, blend );
					} else {
						n_paint_grabber_pixel_get( n_paint_bmp_grab, tx,ty, color, &color_f, &color_t, 0.00 );
						coeff = n_paint_pen_edge( x,y, radius, coeff, blend );
					}


					// [!] : unstable : more time is needed
/*
					u32 color_ret = n_bmp_blend_pixel( color_f, color_t, coeff );

					if ( ( n_paint_pen_boost != 0 )&&( color_f != color_t )&&( color_ret == color_f ) )
					{
						color_ret = n_bmp_blend_pixel_force_move( color_f, color_t, coeff );
					}
*/

					u32 color_ret = n_bmp_blend_pixel_force_move( color_f, color_t, coeff );


					n_paint_grabber_pixel_set( tx,ty, color_f, color_ret );

					n_bmp_ptr_set( &n_paint_bmp_wgrb, tx,ty, 0 );

				}

			}

		}


		x++;
		if ( x > radius )
		{

			x = -radius;

			y++;
			if ( y > radius ) { break; }
		}

	}


	return;
}

// internal
void
n_paint_pen_refresh( n_type_gfx fx, n_type_gfx fy, n_type_gfx tx, n_type_gfx ty )
{

//n_paint_refresh_all(); return;


	// [Needed] : +1

	n_type_gfx redraw_fx = n_posix_min_n_type_gfx( fx, tx ) - n_paint_pen_radius;
	n_type_gfx redraw_fy = n_posix_min_n_type_gfx( fy, ty ) - n_paint_pen_radius;
	n_type_gfx redraw_tx = n_posix_max_n_type_gfx( fx, tx ) + n_paint_pen_radius + 1;
	n_type_gfx redraw_ty = n_posix_max_n_type_gfx( fy, ty ) + n_paint_pen_radius + 1;


//n_win_hwndprintf_literal( hwnd_main, " %d %d ", N_BMP_SX( &n_paint_bmp_scrl ), N_BMP_SX( &n_paint_bmp_wgrb ) );

	if ( n_paint_is_zoom_out( zoom ) )
	{
		n_paint_cache_zero( &n_paint_bmp_scrl );
		n_paint_cache_zero( &n_paint_bmp_wgrb );
/*
		n_type_gfx sx = redraw_tx - redraw_fx;
		n_type_gfx sy = redraw_ty - redraw_fy;

		n_bmp_box( &n_paint_bmp_scrl, redraw_fx, redraw_fy, sx, sy, 0 );
		n_bmp_box( &n_paint_bmp_wgrb, redraw_fx, redraw_fy, sx, sy, 0 );
*/
	}


	n_paint_refresh
	(
		NULL,
		redraw_fx, redraw_fy,
		redraw_tx, redraw_ty,
		N_PAINT_REFRESH_CLIENT,
		N_PAINT_REFRESH_ID_PEN
	);


	return;
}

#define N_PAINT_PEN_START 0
#define N_PAINT_PEN_LOOP  1
#define N_PAINT_PEN_STOP  2

#define n_paint_pen_start() n_paint_pen( N_PAINT_PEN_START )
#define n_paint_pen_loop()  n_paint_pen( N_PAINT_PEN_LOOP  )
#define n_paint_pen_stop()  n_paint_pen( N_PAINT_PEN_STOP  )

void
n_paint_pen( int mode )
{

	static n_type_gfx px;
	static n_type_gfx py;


	n_type_gfx fx,fy, tx,ty;

	n_paint_canvaspos( &tx, &ty );

	if ( mode == N_PAINT_PEN_START )
	{

		n_paint_pen_start_x = px = fx = tx;
		n_paint_pen_start_y = py = fy = ty;

	} else {

		if ( mode == N_PAINT_PEN_STOP )
		{
			if ( ( n_paint_pen_start_x == tx )&&( n_paint_pen_start_y == ty ) ) { return; }
		}

		fx = px;
		fy = py;

	}


	if (
		( mode == N_PAINT_PEN_LOOP )
		&&
		( n_paint_pen_blend != 1.0 )
	)
	{

		// Anti-Shake

		if ( antishake )
		{

			const n_type_gfx threshold = 2;

			if ( threshold <= abs( fx - tx ) ) { tx = ( fx + tx ) / threshold; }
			if ( threshold <= abs( fy - ty ) ) { ty = ( fy + ty ) / threshold; }

		}


		// [!] : nothing to do

		if ( ( fx == tx )&&( fy == ty ) ) { return; }

	}


#ifdef _H_NONNON_WIN32_WIN_WINTAB

//n_win_hwndprintf_literal( hwnd_main, "%d / %d", n_wintab_pressure_get( &n_paint_wintab ), n_wintab_pressure_max( &n_paint_wintab ) );

	if ( n_paint_pen_blend == 1.0 )
	{
		//
	} else
	if ( ( n_paint_wintab_onoff )&&( n_wintab_is_pressed( &n_paint_wintab ) ) )
	{
		double max = n_wintab_pressure_max( &n_paint_wintab );
		double cur = n_wintab_pressure_get( &n_paint_wintab );

		//double pen = (double) pensize * ( cur / max );
		//n_paint_pen_radius = pen / 2;

		n_paint_pen_blend = (double) ( mix * 0.01 ) * ( cur / max );
	}
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB


	if ( n_paint_pen_blend == 1.0 )
	{
		n_bmp_pen_bresenham( fx,fy, tx,ty, n_paint_pen_blend, n_paint_pen_engine );
	} else {
		n_bmp_pen_wu       ( fx,fy, tx,ty, n_paint_pen_blend, n_paint_pen_engine );
	}

	px = tx;
	py = ty;


	n_paint_status();


	n_paint_pen_refresh( fx,fy, tx,ty );


	return;
}

void
n_paint_pen_on_lbuttondown( HWND hwnd )
{

	if ( n_paint_layer_onoff )
	{
		if ( n_paint_layer_is_locked( n_paint_layer_txtbox.select_cch_y ) )
		{
			return;
		}

		n_paint_layer_is_mod[ n_paint_layer_txtbox.select_cch_y ] = n_true;
	}


	if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( n_paint_pen_start == n_false )
		{

			if ( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) ) { return; }
			if ( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) ) { return; }


			n_paint_pen_whole_eraser_onoff = n_posix_false;

			if ( n_paint_layer_onoff )
			{
				if ( n_win_is_input( N_PAINT_PEN_WHOLE_ERASER_VK ) )
				{
					if ( N_PAINT_GRABBER_IS_NEUTRAL() )
					{
						n_paint_pen_whole_eraser_onoff = n_posix_true;
					} else {
						n_project_dialog_info( hwnd_main, n_posix_literal( "Sorry, not implemented yet." ) );
						return;
					}
				}
			}


			n_paint_pen_start = n_true;


			SetCapture( hwnd );


			// [!] : pre-calculate

			n_paint_pen_radius = pensize;
			n_paint_pen_boost  = boost;
			n_paint_pen_color  = n_bmp_argb( cp.a, cp.r, cp.g, cp.b );
			n_paint_pen_blend  = (double) mix * 0.01;

//n_win_hwndprintf_literal( hwnd_main, " %d ", n_paint_pen_radius );

			if ( air != 0 )
			{
				n_paint_pen_boost = 0;
			} else {
				if ( ( mix != 100 )&&( boost != 0 ) )
				{
					n_paint_pen_radius = pensize + boost;
				}
			}

#ifdef _H_NONNON_WIN32_WIN_WINTAB
			if ( ( n_paint_wintab_onoff )&&( n_wintab_is_eraser( &n_paint_wintab ) ) )
			{

				n_paint_pen_color = n_paint_tool_color_transparent_get();

				n_win_cursor_add_literal( NULL, "NONNON_PAINT_ERASER" );

			} else
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB
			{

				if ( n_false == n_paint_quick_eraser )
				{
					n_win_cursor_add_literal( NULL, "NONNON_PAINT_PEN_ON" );
				}

			}


			// [!] : the first input

			n_paint_pen_start();

		}

	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		n_paint_grabber_fill();

	}


	n_paint_colorhistory_add( n_paint_pen_color );


	return;
}

void
n_paint_pen_on_mousemove( HWND hwnd )
{

	n_paint_status();

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( n_paint_pen_start )
		{

			if ( n_win_is_input( N_PAINT_PEN_STRAIGHTLINE_VK ) )
			{
				if ( n_paint_pen_straight_line == n_false )
				{
					n_paint_pen_start();
				}
				n_paint_pen_straight_line = n_true;
				n_paint_refresh_client();
			} else {
				n_paint_pen_loop();
			}

		}

	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		//

	}


	return;
}

void
n_paint_pen_on_lbuttonup( HWND hwnd )
{

	if ( tooltype == N_PAINT_TOOL_TYPE_PEN )
	{

		if ( n_paint_pen_start )
		{

			n_paint_pen_stop();


			ReleaseCapture();


#ifdef _H_NONNON_WIN32_WIN_WINTAB
			if ( ( n_paint_wintab_onoff )&&( n_wintab_is_eraser( &n_paint_wintab ) ) )
			{

				n_win_cursor_add_literal( NULL, "NONNON_PAINT_PEN" );

			} else
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB
			{

				if ( n_false == n_paint_quick_eraser )
				{
					n_win_cursor_add_literal( NULL, "NONNON_PAINT_PEN" );
				}

			}


			n_paint_pen_start = n_false;

		}

	} else
	if ( tooltype == N_PAINT_TOOL_TYPE_FILL )
	{

		//

	}


	return;
}

void
n_paint_pen_cursor_move( n_type_gfx delta_x, n_type_gfx delta_y )
{

	POINT p; GetCursorPos( &p );
	SetCursorPos( p.x + delta_x, p.y + delta_y );

	return;
}

void
n_paint_pen_key2cursor( void )
{

	n_type_gfx step = 1;

	if ( n_paint_is_zoom_in( zoom ) ) { step = n_paint_zoom_get( zoom ); }

	n_type_gfx x = 0;
	n_type_gfx y = 0;

	if ( n_win_is_input( VK_UP    ) ) { y -= step; }
	if ( n_win_is_input( VK_DOWN  ) ) { y += step; }
	if ( n_win_is_input( VK_LEFT  ) ) { x -= step; }
	if ( n_win_is_input( VK_RIGHT ) ) { x += step; }

	n_paint_pen_cursor_move( x, y );


	return;
}

n_bool
n_paint_is_clientarea( void )
{

	POINT p; GetCursorPos( &p );

	ScreenToClient( hwnd_main, &p );

	RECT r; GetClientRect( hwnd_main, &r );


	return(
		( p.x >= 0 )&&( p.y >= 0 )
		&&
		( p.x < r.right )&&( p.y < r.bottom )
	);
}

int
n_paint_pen_proc( HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam )
{
//return 0;

	if ( n_paint_on_setcursor_condition() )
	{
		if ( n_paint_pen_start == n_false )
		{
			return n_paint_on_setcursor( hwnd, msg, wparam, lparam );
		}
	}


	// [!] : grabber is ON

	if ( tooltype == N_PAINT_TOOL_TYPE_GRAB )
	{
		if ( n_paint_is_shiftzoom )
		{
			n_paint_is_shiftzoom = n_false;
			n_paint_refresh_client();
		}

		return 0;
	}


	if ( n_paint_resizer_backup_onoff )
	{

		switch( msg ) {

		case WM_LBUTTONDBLCLK :
		{
			if ( n_false == n_paint_resizer_vanishing_point_combo_is_selected() ) { break; }

			n_type_gfx x,y; n_paint_canvaspos( &x, &y );

			n_paint_resizer_vanishing_point_x = x;
			n_paint_resizer_vanishing_point_y = y;

			extern void n_paint_resizer_backup_go( void );
			n_paint_resizer_backup_go();
		}
		break;

		case WM_RBUTTONDBLCLK :
		{
			n_paint_resizer_vanishing_point_x = -1;
			n_paint_resizer_vanishing_point_y = -1;

			extern void n_paint_resizer_backup_go( void );
			n_paint_resizer_backup_go();
		}
		break;

		} // switch


		return n_paint_on_setcursor( hwnd, msg, wparam, lparam );
	}


	if ( n_paint_layer_rename_onoff ) { return 0; }


	switch( msg ) {


	case WM_KEYDOWN :

		if ( n_paint_layer_onoff )
		{
			n_type_int y = n_paint_layer_txtbox.select_cch_y;
			if ( n_false == n_paint_layer_data[ y ].visible ) { break; }
		}

		if ( n_win_is_hovered( hwnd_layr ) ) { break; }

		if ( wparam == VK_SHIFT )
		{
			if (
				( n_false == n_win_is_input( VK_CONTROL ) )
				&&
				( n_paint_pen_start    == n_false )
				&&
				( n_paint_is_shiftzoom == n_false )
			)
			{
				n_paint_is_shiftzoom = n_true;
				n_paint_refresh_client();

				n_win_cursor_add( NULL, IDC_ARROW );
				n_win_cursor_add( hwnd, IDC_ARROW );
			}
		}

	break;

	case WM_KEYUP :

		if ( wparam == N_PAINT_PEN_STRAIGHTLINE_VK )
		{
			if ( n_paint_pen_start )
			{
				n_paint_pen_on_lbuttonup( hwnd );

				if ( n_paint_pen_straight_line )
				{
					n_paint_pen_straight_line = n_false;
					n_paint_refresh_client();
				}

				n_paint_pen_on_lbuttondown( hwnd );
			}
		} else
		if ( wparam == VK_SHIFT )
		{
			if ( n_false == n_win_is_input( VK_LBUTTON ) )
			{
				n_paint_is_shiftzoom = n_false;

				// [Needed] : 64-bit : High-DPI
				n_bmp_flush( &n_paint_bmp_dbuf, N_PAINT_CANVAS_COLOR );

				n_paint_refresh_client();

				if ( n_paint_is_clientarea() )
				{
					n_paint_pen_cursor_default( NULL );
					n_paint_pen_cursor_default( hwnd );
				} else {
					n_win_cursor_add( NULL, IDC_ARROW );
					n_paint_pen_cursor_default( hwnd );
				}
			}
		}

	break;


	case WM_LBUTTONDOWN :

		{
			n_type_gfx x,y,sx,sy; n_paint_hamburger_get( &x,&y,&sx,&sy );

			if ( n_win_is_hovered_offset( hwnd, x,y,sx,sy ) )
			{
				break;
			}
		}


		if ( wparam & MK_SHIFT )
		{
			if ( ( n_paint_pen_start == n_false )&&( n_paint_is_shiftzoom == n_false ) )
			{
				n_paint_is_shiftzoom = n_true;
				n_paint_refresh_client();
			}
		} else {
			n_paint_pen_on_lbuttondown( hwnd );
		}

	break;

	case WM_MOUSEMOVE :
//n_win_hwndprintf_literal( hwnd_main, " %d ", n_win_is_input( VK_CONTROL ) );

#ifdef _H_NONNON_WIN32_WIN_WINTAB
		if ( n_paint_wintab_onoff )
		{
			if ( n_wintab_is_eraser( &n_paint_wintab ) )
			{
				n_win_cursor_add_literal( hwnd, "NONNON_PAINT_ERASER" );
			} else {
				//
			}
		}
#endif // #ifdef _H_NONNON_WIN32_WIN_WINTAB

		n_paint_pen_on_mousemove( hwnd );

	break;

	case WM_LBUTTONUP :

		if ( n_paint_is_shiftzoom )
		{

			if (
				( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
				||
				( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
			)
			{
				break;
			}

			n_type_gfx cur; n_win_cursor_position_relative( hwnd_main, NULL, &cur );
			n_type_gfx pos = 0;
			if ( cur < ( nwin_main.csy / 2 ) )
			{
				pos =  1;
			} else
			if ( cur > ( nwin_main.csy / 2 ) )
			{
				pos = -1;
			} 
			n_paint_tool_scrollbar_updown( &n_paint_tool_hscr[ 4 ], pos );

		} else {

			n_paint_pen_on_lbuttonup( hwnd );

			if ( n_paint_pen_straight_line )
			{
				n_paint_pen_straight_line = n_false;
				n_paint_refresh_client();
			}

		}

	break;


	case WM_RBUTTONDOWN :
//n_win_debug_count( hwnd ); break;

		if ( n_paint_is_shiftzoom ) { break; }

		if ( n_win_is_input( VK_LBUTTON ) ) { break; }

		if (
			( n_paint_hscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
			||
			( n_paint_vscr.hwnd == n_win_cursor2hwnd_relative( hwnd_main ) )
		)
		{
			//
		} else {
			n_paint_colorpicker();
		}

	break;


	} // switch


	return n_false;
}

