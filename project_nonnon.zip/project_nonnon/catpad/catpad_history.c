// CatPad
// copyright (c) nonnon all rights reserved
// License : GPL http://www.gnu.org/copyleft/gpl.html


// Partial File




#define N_CATPAD_HISTORY_MAX ( 10 )


static n_posix_char     *n_catpad_history_string[ N_CATPAD_HISTORY_MAX ];
static n_win_simplemenu  n_catpad_history_menu;




n_posix_bool
n_catpad_history_is_same( const n_posix_char *str )
{

	n_posix_bool ret = n_posix_false;

	int i = 0;
	n_posix_loop
	{

		n_posix_char *cmp = n_catpad_history_string[ i ];

		if ( n_string_is_same( str, &cmp[ 3 ] ) )
		{
			ret = n_posix_true;
			break;
		}

		i++;
		if ( i >= N_CATPAD_HISTORY_MAX ) { break; }
	}


	return ret;
}

void
n_catpad_history_add( const n_posix_char *str )
{

	if ( n_string_is_empty( str ) ) { return; }

	if ( n_catpad_history_is_same( str ) ) { return; }


	int last = N_CATPAD_HISTORY_MAX - 1;

	n_string_free( n_catpad_history_string[ last ] );

	int i = 0;
	n_posix_loop
	{

		n_catpad_history_string[ last - i ] = n_catpad_history_string[ last - i - 1 ];

		i++;
		if ( i >= last ) { break; }
	}

	{

		n_type_int cch = n_posix_strlen( str ) + n_posix_strlen_literal( "[ ]" );

		n_catpad_history_string[ 0 ] = n_string_new( cch );

		n_posix_sprintf_literal( n_catpad_history_string[ 0 ], "[ ]%s", str );
	}


	i = 0;
	n_posix_loop
	{//break;
//n_posix_debug_literal( "%d : %s", i, n_catpad_history_string[ i ] );

		n_win_simplemenu_mod( &n_catpad_history_menu, i, NULL, n_catpad_history_string[ i ], NULL );

		i++;
		if ( i >= N_CATPAD_HISTORY_MAX ) { break; }
	}


	return;
}

void
n_catpad_history_init( void )
{

	n_win_simplemenu_zero( &n_catpad_history_menu );
	n_win_simplemenu_init( &n_catpad_history_menu );

	n_catpad_history_menu.option_relative_hwnd = n_catpad_txtbox_search.hwnd;


	int i = 0;
	n_posix_loop
	{

		n_catpad_history_string[ i ] = n_string_new( 100 );

		//n_posix_sprintf_literal( n_catpad_history_string[ i ], "[ ]%d : %s", i, N_CATPAD_APPNAME_LITERAL );
		n_posix_sprintf_literal( n_catpad_history_string[ i ], "[ ]%d", i );

		n_win_simplemenu_set( &n_catpad_history_menu, i, NULL, n_catpad_history_string[ i ], NULL );

		i++;
		if ( i >= N_CATPAD_HISTORY_MAX ) { break; }
	}


	if ( n_posix_false == n_string_is_empty( n_catpad_find ) )
	{
		n_catpad_history_add( n_catpad_find );
	}


	return;
}

void
n_catpad_history_exit( void )
{

	n_win_simplemenu_exit( &n_catpad_history_menu );


	int i = 0;
	n_posix_loop
	{

		n_string_free( n_catpad_history_string[ i ] );

		i++;
		if ( i >= N_CATPAD_HISTORY_MAX ) { break; }
	}


	return;
}

void
n_catpad_history_show( void )
{

	if ( n_win_simplemenu_target != NULL )
	{
		n_win_simplemenu_hide( &n_catpad_history_menu );
	} else {
		n_win_simplemenu_show( &n_catpad_history_menu, GetParent( n_catpad_heditor ) );
	}


	return;
}


